﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OOP2
{   //Burada da tüzel müşteriye ait olan özellikleri oluşturacağız sadece.
    //Corporate
    class TuzelMusteri : Musteri
    {
      

        public string SirketAdi { get; set; }

        public string VergiNo { get; set; }


    }
}
