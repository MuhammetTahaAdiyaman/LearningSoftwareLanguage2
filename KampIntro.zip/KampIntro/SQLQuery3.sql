﻿--select = ilk öğreneceğimiz komut olan "select" = bir veri kaynağında olan data'yı çekmek için kullanılan yapıdır */
--select * from Customers --bu kodun anlamlarına bakacağız şimdi, select(data'yı seç), select'en sonra gelen kısım kolonları temsil eder ancak *(tüm kolonları kapsar), from(nereden, hangi tablodan), Customers(customer tablosundan tüm kolonları kapsayarak veriyi çek anlamına geliyor diyebiliriz) */
--yukarıdaki kodu yorum satırına alacağım yıldızın üzerine getirdiğimizde visual studio bize bu database'den neleri çağırabileceğimzizi gösteriyor şimdi biz ContactName, CompanyName, City, kolonlarını getirelim aşağıda. 
--Select ContactName, CompanyName, City from Customers --execute yaptığımızda aşağıda çağırdığımız kolonları görüyoruz. Aslında bu kodu çalıştırdığımızda fake bir tablo oluşturuyor  memory'de o tabloyu bize gösteriyor. aşağıda gördüğümüz ise görünen kısmı. Bu aslında bir tablo neden bu şekilde söyledik ilerleyen zamanlarda biz sorguya'da select atmak isteyebiliriz bu durum yanlışdır aslında bir sorgu yazıp onu başka bir tablo ile join etmemiz gerekmektedir. şimdilik bunun bir tablo olduğunun bilincinde olalım. 
--yukarıdaki kodu yorum satırına alıyorum yeni bir şey daha öğrenelim eğer biz database'den veri geleceğinde isimlerini işte ContactName'i Adi olarak, CompanyName'i şirketAdi olarak, City'i şehir olarak getirmesini istersek aşağıdaki gibi yazmamız gerekmektedir.
Select ContactName Adi, CompanyName SirketAdi, City Sehir from Customers --bu tür kullanıma alyans denir biz bunu c# içinde foreach veya for döngüsünde kullanıyorduk. bu şekilde yazdığımızda isimleri istedigimiz şekilde database'den getirtebilme imkanımız oluyor.
--Bu kodlarımız MySql, Oracle da da çalışır bu kodlarda dersin başında bahsettiğimiz ANSII standartı özelliğine sahip olmasıdır.
--diğer bir sorgu çeşidimiz ise filtreleme yöntemidir. Yani data içinde örnek veriyorum bana sadece london şehrinde oturanları getir demek istiyoruz bunu aşağıda nasıl yazacağımızı gösterelim.
Select * from Customers where City = 'London' --where(koşul demek) (bu şu demek tekrar edersek database'de olan ve şehri londra olanları bana getir demek)



