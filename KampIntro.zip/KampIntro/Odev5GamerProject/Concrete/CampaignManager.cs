﻿using Odev5GamerProject.Abstract;
using Odev5GamerProject.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Odev5GamerProject.Concrete
{
    class CampaignManager : ICampaignService
    {
        public void Add(Campaign campaign)
        {
            Console.WriteLine(campaign.CampaignName + "campaign added");
        }

        public void Delete(Campaign campaign)
        {
            Console.WriteLine(campaign.CampaignName + "campaign deleted");
        }

        public void Update(Campaign campaign)
        {
            Console.WriteLine(campaign.CampaignName + "campaign uptaded");
        }
    }
}
