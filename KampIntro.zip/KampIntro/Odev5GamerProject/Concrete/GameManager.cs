﻿using Odev5GamerProject.Abstract;
using Odev5GamerProject.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Odev5GamerProject.Concrete
{
    class GameManager : IGameService
    {
        public void Add(Game game)
        {
            Console.WriteLine(game.Name + "Added");
        }

        public void Delete(Game game)
        {
            Console.WriteLine(game.Name + "Deleted");
        }

        public void Update(Game game)
        {
            Console.WriteLine(game.Name + "Uptaded");
        }
    }
}
