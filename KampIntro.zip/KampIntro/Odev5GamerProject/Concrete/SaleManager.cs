﻿using Odev5GamerProject.Abstract;
using Odev5GamerProject.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Odev5GamerProject.Concrete
{
    class SaleManager : ISaleService
    {
        public void CampaignSale(Gamer gamer, Game game, Campaign campaign)
        {
            Console.WriteLine("Name: " + gamer.FirstName + " \n " + "LastName: " + gamer.LastName + "\n" + "purchased the game Name: " + game.Name + "\n" + "Game price: " + game.Price * campaign.CampaignDiscount / 100 + "% discount");
        }

        public void Sale(Gamer gamer, Game game)
        {
            Console.WriteLine("Name: " + gamer.FirstName + " \n " + "LastName: " + gamer.LastName + "\n" + "purchased the game Name: " + game.Name);
        }
    }
}
