﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Odev5GamerProjectt.Entity
{
    class Campaign
    {
        public int CampaignId { get; set; }

        public string CampaignName { get; set; }

        public float CampaignDiscount { get; set; }
    }
}
