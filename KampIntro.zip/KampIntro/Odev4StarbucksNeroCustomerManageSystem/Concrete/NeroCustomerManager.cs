﻿using Odev4StarbucksNeroCustomerManageSystem.Abstract;
using System;
using System.Collections.Generic;
using System.Text;

namespace Odev4StarbucksNeroCustomerManageSystem.Concrete
{
    public class NeroCustomerManager : BaseCustomerManager
    {

    }
}
